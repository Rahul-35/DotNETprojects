﻿using Microsoft.EntityFrameworkCore;
using MyMicroWebAPI.Models;

namespace MyMicroWebAPI.Data
{
    public class ProductContext:DbContext
    {
        public ProductContext(DbContextOptions<ProductContext> opt):base(opt)
        {
            
        }
        public DbSet<Product> MyProducts { get; set; }
    }
}
