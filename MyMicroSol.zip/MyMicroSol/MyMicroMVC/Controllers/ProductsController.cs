﻿using Microsoft.AspNetCore.Mvc;
using MyMicroMVC.Models;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MyMicroMVC.Controllers
{
    public class ProductsController : Controller
    {
        public async Task<IActionResult> Index()
        {
            
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:5000/");
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage res = await client.GetAsync("api/MyPros");
                if (res.IsSuccessStatusCode) { 
                    var Response=await res.Content.ReadAsStringAsync();
                    var ProInfo= JsonSerializer.Deserialize<IEnumerable<Products>>(Response, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    return View(ProInfo);
                }
                return View(new List<Products>());
            }
        }
    }
}
