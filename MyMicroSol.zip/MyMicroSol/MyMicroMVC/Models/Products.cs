﻿namespace MyMicroMVC.Models
{
    public class Products
    {
        public int ID { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }
        public double Price { get; set; }
    }
}
