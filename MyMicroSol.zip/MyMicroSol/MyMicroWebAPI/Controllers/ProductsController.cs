﻿using Microsoft.AspNetCore.Mvc;
using MyMicroWebAPI.Data;
using MyMicroWebAPI.Models;

namespace MyMicroWebAPI.Controllers
{
    [ApiController]
    [Route("api/MyPros")]
    public class ProductsController : ControllerBase
    {
        private readonly ProductContext _context;
        public ProductsController(ProductContext context)
        {
            _context = context; 
        }
        [HttpGet]
        public IEnumerable<Product> GetAllProducts()
        {
            return _context.MyProducts.ToList();
        }

        [HttpGet("{id}")]

        public ActionResult<Product> GetByID(int id)
        {
            var con = _context.MyProducts.Find(id);
            if (con == null)
            {
                return NotFound();
            }
            return Ok(con);
        }
        [HttpDelete("{id}")]
        public ActionResult DeleteByID(int id) {
            var con = _context.MyProducts.Find(id);
            if (con == null)
            {
                return NotFound();
            }
            _context.MyProducts.Remove(con);
            _context.SaveChanges();
            return NoContent();
        }

        [HttpPost]
        public ActionResult<Product> CreateProduct(Product product)
        {
            _context.MyProducts.Add(product);
            _context.SaveChanges();
            return Created($"/api/MyPros/{product.ID}", product);
        }

        [HttpPut("id")]
        public ActionResult<Product> UpdateProduct(int id, Product newpro)
        {
            var con=_context.MyProducts.Find(id);
            if (con == null)
            {
                return NotFound();
            }
            con.Name=newpro.Name;
            con.Price=newpro.Price;
            con.Type = newpro.Type;
            _context.SaveChanges();
            return Ok(con);
        }
    }
}
